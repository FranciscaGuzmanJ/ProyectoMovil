import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-albumes',
  templateUrl: './albumes.page.html',
  styleUrls: ['./albumes.page.scss'],
})
export class AlbumesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }
}
