// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyC89gtm0h5svvoQmtY17o-8BqQZwjDJ69k",
    authDomain: "proyectomovilduoc-ed5e5.firebaseapp.com",
    projectId: "proyectomovilduoc-ed5e5",
    storageBucket: "proyectomovilduoc-ed5e5.appspot.com",
    messagingSenderId: "807366935860",
    appId: "1:807366935860:web:b9655832e562511d981161",
    measurementId: "G-EB2X808QR6"
  }
  
};


/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
